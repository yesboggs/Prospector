# Prospector
Gibson's Prospector Solitaire
